<?php

// $link=new PDO('mysql:host=sqletud.u-pem.fr;dbname=testev01_db', 'testev01', 'taniammi', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));

$link=new PDO('mysql:host=LOCALHOST;dbname=AstronoMMI', 'root', '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));

?>